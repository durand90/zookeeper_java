package com.fanfan.zooker;

public class TestZoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Gorilla bam = new Gorilla(75);
		Gorilla coco = new Gorilla(60);
		
		coco.displayEnergy();
		
		bam.throwSomething();
//		bam.displayEnergy();
//		bam.throwSomething();
//		bam.displayEnergy();
//		bam.throwSomething();
//		bam.displayEnergy();
//		bam.eatBananas();
//		bam.displayEnergy();
//		bam.eatBananas();
//		bam.displayEnergy();
//		bam.climb();
//		bam.displayEnergy();

	}

}
